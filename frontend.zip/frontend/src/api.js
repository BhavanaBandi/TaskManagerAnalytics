import axios from 'axios';

const BASE_URL = 'http://localhost:5000'; // Change this when you deploy
const API = axios.create({ baseURL: BASE_URL });

// Add JWT to every request if present
API.interceptors.request.use((req) => {
  const token = localStorage.getItem('token');
  if (token) {
    req.headers.Authorization = `Bearer ${token}`;
  }
  return req;
});

// Register new user
export const registerUser = async (formData) => {
  const res = await API.post('/register', formData);
  return res.data;
};

// Login user
export const loginUser = async (formData) => {
  const res = await API.post('/login', formData);
  return res.data;
};

// Get tasks for user
export const getTasks = async () => {
  const res = await API.get('/tasks');
  return res.data;
};

// Create a new task
export const createTask = async (taskData) => {
  const res = await API.post('/tasks', taskData);
  return res.data;
};
